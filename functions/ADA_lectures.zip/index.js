const books = require('./books.json');

function compare(a, b) {
  if (a.note < b.note) return 1;
  if (a.note > b.note) return -1;
  return 0;
}
// 1. recherche titre
// 2. coup de coeur ADA
// 3. categorie
// 4. taille du livre
// 5. trié par note
const findBooks = async function findBooks(event) {
  if (event.id) {
    const book = books.filter((b) => (b.id === event.id));
    if (book.length > 0) return book[0];
  }
  let res = books;
  if (event.search && event.search.length > 0) {
    res = res.filter((m) => m.title.indexOf(event.search) !== -1);
  }
  if (event.cdc) {
    res = res.filter((m) => m.cdc.length > 0);
  }
  if (event.category && event.category.length > 0 && event.category !== 'any') {
    res = res.filter((m) => m.category === event.category);
  }
  if (event.size && event.size !== 'any') {
    res = res.filter((m) => m.size < event.size);
  }
  if (event.is_sorted) {
    res = res.sort(compare);
  } else {
    res = res.sort(() => Math.random() - 0.5);
  }
  return res.slice(0, 5);
};
exports.handler = async (event) => findBooks(event);
